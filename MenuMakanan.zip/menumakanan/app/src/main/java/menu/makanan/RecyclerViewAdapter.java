package menu.makanan;


import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>{

    public  class ViewHolder extends RecyclerView.ViewHolder
    {
        ImageView imageview2;
        TextView mkn1;
        ConstraintLayout constraintLayout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageview2 = itemView.findViewById(R.id.imageView2);
            mkn1 = itemView.findViewById(R.id.mkn1);
            constraintLayout = itemView.findViewById(R.id.constraintLayout);
        }
    }

}
